<template>
    <v-app>
      <v-app-bar  height="120" app>
        <v-container class="fundo">
          <v-row align="center" no-gutters>
            <!-- Logo on the left -->
            <v-col cols="auto">
              <v-img
                class="mx-auto"
                width="150"
                height="auto"
                :src="require('@/assets/logo.jpeg')"
              ></v-img>
            </v-col>
            <v-col class="ml-10">
              <v-toolbar-title>Gestão Clínica em Saúde Mental</v-toolbar-title>
            </v-col>
            <v-spacer></v-spacer>
            <!-- Navigation buttons -->
            <v-col cols="auto">
              <v-btn text :href="'#section1'">Sobre o Psibetter</v-btn>
              <v-btn text :href="'#section2'">Funcionalidades</v-btn>
              <v-btn text :href="'#section3'">Contato</v-btn>
              <v-btn text :href="'#section3'">Planos</v-btn>
            </v-col>
          </v-row>
        </v-container>
      </v-app-bar>
  
      <v-main>
        <v-container>
          <v-row> 
            <v-carousel show-arrows="hover">
                <v-carousel-item
                    src="https://cdn.vuetifyjs.com/images/cards/docks.jpg"
                    cover
                ></v-carousel-item>

                <v-carousel-item
                    src="https://cdn.vuetifyjs.com/images/cards/hotel.jpg"
                    cover
                ></v-carousel-item>

                <v-carousel-item
                    src="https://cdn.vuetifyjs.com/images/cards/sunshine.jpg"
                    cover
                ></v-carousel-item>
                </v-carousel>  
          </v-row> 

          <v-row>
            <v-col>
              <v-sheet class="py-5" id="section1">
                <v-subheader>Section 1</v-subheader>
                <p>Welcome to Section 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </v-sheet>
              <v-sheet class="py-5" id="section2">
                <v-subheader>Section 2</v-subheader>
                <p>Welcome to Section 2. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
              </v-sheet>
              <v-sheet class="py-5" id="section3">
                <v-subheader>Section 3</v-subheader>
                <p>Welcome to Section 3. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </v-sheet>
            </v-col>
          </v-row>
        </v-container>
      </v-main>
    </v-app>
  </template>
  
  <script>
  /* eslint-disable */
  export default {
    name: 'Website',
  }
  </script>
  
  <style>
  html {
    scroll-behavior: smooth;
  }
  
  .fundo {
    background: linear-gradient(to left, #5a9e00, #b2e48a); /* Gradient colors */
    width: 100%;
  }

  #section1,
  #section2,
  #section3 {
    min-height: 100vh;
    padding: 20px;
  }
  </style>
  