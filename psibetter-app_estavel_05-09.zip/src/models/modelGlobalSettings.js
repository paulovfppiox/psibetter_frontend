/**
 * URLs devem estar exatamente igual à main.js --->> app.config.globalProperties.$SERVICES_ENDPOINT_URL  
 */
// PRODUÇÃO
export const ENDPOINT_URL = "http://184.72.238.232/psibetter/psibetter_backend/services-api.php";

// export const ENDPOINT_URL = "http://localhost/psibetter_backend/services-api.php";
