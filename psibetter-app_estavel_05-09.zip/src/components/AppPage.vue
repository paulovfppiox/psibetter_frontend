<template>
  <v-app> PAGINA </v-app>
  oi oi oi oi oi oi 
</template>

<script setup> 
 
</script>

<script>
  export default {
    data: () => ({  
    }),
  }
</script>