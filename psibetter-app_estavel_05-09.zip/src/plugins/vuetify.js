/* eslint-disable */
import { createVuetify } from 'vuetify';
import { VCalendar } from 'vuetify/labs/VCalendar'

export default createVuetify({
  components: {
    VCalendar,
  },
})